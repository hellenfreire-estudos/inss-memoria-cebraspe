# INSS Memória NASA — Fase Final Robusta

- 300 questões AUTORAIS NASA.
- 360 referências de itens OFICIAIS CEBRASPE: 120 básicos 2022 + 120 específicos 2022 + 120 oficiais 2026.
- Missões de 5 itens.
- Prioridade por erro, recência e intervalo.
- Erro: retorno rápido para fixação.
- Acerto: ampliação do intervalo.
- Questões dominadas: menor prioridade.
- Histórico persistido no aparelho.
- PWA: manifest + service worker.

IMPORTANTE: o texto integral das questões oficiais não é reproduzido neste pacote. O índice oficial aponta para os documentos do Cebraspe. Para colocar o texto integral da banca dentro do aplicativo, é necessário fornecer os cadernos oficiais como arquivos de origem para importação.


## PUSH
O pacote inclui cliente Web Push, Service Worker e um servidor mínimo em `push-server/`. O servidor é necessário para notificações com o PWA fechado; não usamos OneSignal. A Apple documenta que Web Push em Home Screen web apps usa Push API + Notifications API + Service Worker e um servidor que envia as notificações.
